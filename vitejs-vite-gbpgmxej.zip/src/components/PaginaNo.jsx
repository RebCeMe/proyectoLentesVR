import React from 'react'

const PaginaNo = () => {
  return (
    <div><h1>Pagina no encontrada</h1></div>
  )
}

export default PaginaNo